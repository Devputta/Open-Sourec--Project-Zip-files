import React, { useState } from 'react';
import { IncidentRecord } from '../types/game';

interface IncidentArchiveProps {
  incidents: IncidentRecord[];
  onBack: () => void;
}

export const IncidentArchive: React.FC<IncidentArchiveProps> = ({ incidents, onBack }) => {
  const [selectedId, setSelectedId] = useState<string | null>(
    incidents.length > 0 ? incidents[0].id : null
  );

  const selectedIncident = incidents.find((i) => i.id === selectedId) || (incidents.length > 0 ? incidents[0] : null);

  // Calculate unique chambers failed
  const failedChambers = new Set(incidents.map((i) => i.levelNumber)).size;

  return (
    <div className="w-full font-mono text-[#f2ede4]">
      {/* Archive Header */}
      <div className="flex items-baseline justify-between border-b border-[#2d2b27] pb-3 mb-6">
        <div>
          <div className="text-[10px] text-[#787165] uppercase tracking-widest mb-1">
            PLANT FATALITY REGISTRY · CLASSIFIED
          </div>
          <h1 className="text-xl sm:text-2xl font-display font-bold text-[#f2ede4] uppercase">
            Black Box Incident Archive
          </h1>
        </div>

        <button
          type="button"
          onClick={onBack}
          className="text-xs text-[#d96528] hover:text-[#eb7b3d] font-bold uppercase transition-colors cursor-pointer"
        >
          ← Return to Console
        </button>
      </div>

      {/* Session Status Ledger */}
      <div className="mb-8">
        <div className="text-[11px] font-bold text-[#8a8479] uppercase tracking-wider mb-2">
          SESSION STATUS
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs border-y border-[#262421] py-3 text-[#b8b0a1]">
          <div>
            <span className="text-[#696358] uppercase block text-[10px]">CHAMBERS WITH INCIDENTS</span>
            <span className="font-bold text-[#f2ede4] text-sm tabular-nums">0{failedChambers} / 05</span>
          </div>
          <div>
            <span className="text-[#696358] uppercase block text-[10px]">FAILURES RECORDED</span>
            <span className="font-bold text-[#f2ede4] text-sm tabular-nums">0{incidents.length}</span>
          </div>
          <div>
            <span className="text-[#696358] uppercase block text-[10px]">CORONER CLASSIFICATION</span>
            <span className="font-bold text-[#d96528] text-sm">
              {incidents.length === 0 ? 'CLEAN RECORD' : 'MULTIPLE BAD DECISIONS'}
            </span>
          </div>
        </div>
      </div>

      {/* Incident Records Registry */}
      <div>
        <div className="text-[11px] font-bold text-[#8a8479] uppercase tracking-wider mb-3">
          INCIDENT RECORDS
        </div>

        {incidents.length === 0 ? (
          <div className="space-y-2 text-xs text-[#5e584f]">
            <p className="text-[#a8a194] italic mb-4">
              NO INCIDENTS RECORDED.
            </p>
            <div className="flex items-center justify-between border-b border-[#211f1d] py-1.5">
              <span>01</span>
              <span className="text-[#36332e]">──────────────────────────────────────────</span>
              <span>EMPTY</span>
            </div>
            <div className="flex items-center justify-between border-b border-[#211f1d] py-1.5">
              <span>02</span>
              <span className="text-[#36332e]">──────────────────────────────────────────</span>
              <span>EMPTY</span>
            </div>
            <div className="flex items-center justify-between border-b border-[#211f1d] py-1.5">
              <span>03</span>
              <span className="text-[#36332e]">──────────────────────────────────────────</span>
              <span>EMPTY</span>
            </div>
            <div className="flex items-center justify-between border-b border-[#211f1d] py-1.5">
              <span>04</span>
              <span className="text-[#36332e]">──────────────────────────────────────────</span>
              <span>EMPTY</span>
            </div>
            <div className="flex items-center justify-between border-b border-[#211f1d] py-1.5">
              <span>05</span>
              <span className="text-[#36332e]">──────────────────────────────────────────</span>
              <span>EMPTY</span>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
            {/* Record List */}
            <div className="md:col-span-5 divide-y divide-[#262421]">
              {incidents.map((inc, idx) => {
                const isSelected = (selectedIncident?.id === inc.id);
                return (
                  <button
                    key={inc.id || idx}
                    type="button"
                    onClick={() => setSelectedId(inc.id)}
                    className={`w-full text-left py-2.5 flex items-center justify-between text-xs transition-colors cursor-pointer ${
                      isSelected
                        ? 'text-[#d96528] font-bold'
                        : 'text-[#9c9588] hover:text-[#f2ede4]'
                    }`}
                  >
                    <div className="flex items-center gap-3 truncate">
                      <span className="text-[#59544b] font-mono shrink-0">
                        {String(idx + 1).padStart(2, '0')}
                      </span>
                      <span className="truncate uppercase">
                        {inc.incidentTitle}
                      </span>
                    </div>
                    <span className="text-[10px] text-[#5e584e] shrink-0 ml-2">
                      CH-0{inc.levelNumber}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Selected Incident Report (Direct Typed Sheet) */}
            {selectedIncident && (
              <div className="md:col-span-7 bg-[#1a1917] border border-[#33302b] p-5 sm:p-6 text-[#ded7ca] text-xs space-y-4">
                <div className="border-b border-[#2e2b27] pb-3">
                  <div className="text-[10px] text-[#8a8479] uppercase">
                    CHAMBER 0{selectedIncident.levelNumber} · {selectedIncident.levelTitle}
                  </div>
                  <h2 className="text-base sm:text-lg font-display font-bold text-[#d96528] uppercase mt-0.5">
                    {selectedIncident.incidentTitle}
                  </h2>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-[#706a5e] uppercase block mb-1">
                    CAUSE
                  </span>
                  <p className="text-[#ded7ca] leading-relaxed">
                    {selectedIncident.incidentCause}
                  </p>
                </div>

                <div>
                  <span className="text-[10px] font-bold text-[#706a5e] uppercase block mb-1">
                    INCIDENT DESCRIPTION
                  </span>
                  <p className="text-[#b8b0a1] leading-relaxed italic border-l-2 border-[#7a2e22] pl-3">
                    "{selectedIncident.incidentReport}"
                  </p>
                </div>

                <div className="pt-2 border-t border-[#2e2b27] flex items-center justify-between text-[10px] text-[#706b61]">
                  <span>TRIGGERED ON MOVE: 0{selectedIncident.moveCount}</span>
                  <span>RECORD PERMANENTLY PRESERVED</span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
