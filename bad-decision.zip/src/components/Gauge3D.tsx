import React, { useState, useEffect } from 'react';
import { sound } from '../audio/sound';
import { Gauge, Activity, ShieldAlert } from 'lucide-react';

interface Gauge3DProps {
  initialPressure?: number;
  min?: number;
  max?: number;
  label?: string;
  unit?: string;
  className?: string;
}

export const Gauge3D: React.FC<Gauge3DProps> = ({
  initialPressure = 480,
  min = 0,
  max = 1000,
  label = 'LINE PRESSURE',
  unit = 'PSI',
  className = '',
}) => {
  const [pressure, setPressure] = useState<number>(initialPressure);
  const [autoCycle, setAutoCycle] = useState<boolean>(false);

  // Clamp and calculate needle angle across 240-degree arc (-120° to +120°)
  const clampedPressure = Math.max(min, Math.min(max, pressure));
  const percentage = (clampedPressure - min) / (max - min);
  const needleAngle = -120 + percentage * 240;

  // Auto-cycle simulation effect to showcase smooth needle interpolation
  useEffect(() => {
    if (!autoCycle) return;

    const testValues = [80, 260, 520, 840, 960, 420, 150];
    let idx = 0;

    const interval = setInterval(() => {
      idx = (idx + 1) % testValues.length;
      setPressure(testValues[idx]);
      sound.playMeterTick();
    }, 2200);

    return () => clearInterval(interval);
  }, [autoCycle]);

  const isCritical = clampedPressure >= 800;
  const isOptimal = clampedPressure >= 200 && clampedPressure <= 600;

  const handleSetPressure = (val: number) => {
    setAutoCycle(false);
    setPressure(val);
    sound.playSwitchClick();
  };

  return (
    <div className={`relative w-full font-mono select-none ${className}`}>
      {/* 3D Perspective Instrument Enclosure */}
      <div className="relative rounded-xs border-2 border-[#38332a] bg-[#121110] p-4 sm:p-5 shadow-[0_16px_40px_rgba(0,0,0,0.9)] overflow-hidden">
        {/* Top Chassis Header */}
        <div className="flex items-center justify-between border-b border-[#2b2721] pb-2.5 mb-3 text-[10px]">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full border border-black/50"
              style={{
                backgroundColor: isCritical ? '#d93829' : isOptimal ? '#4f8f53' : '#d96528',
                boxShadow: isCritical ? '0 0 8px #d93829' : '0 0 6px #d96528'
              }}
            />
            <span className="font-bold text-[#d96528] tracking-widest uppercase flex items-center gap-1.5">
              <Gauge size={13} />
              <span>GAUGE-3D INSTRUMENT UNIT</span>
            </span>
          </div>
          <span className="text-[#696356] tracking-wider text-[9px] uppercase">
            MODEL 1974-V3 · ANALOG PNEUMATIC
          </span>
        </div>

        {/* 3D Viewport with Isometric Tilt */}
        <div className="perspective-[1000px] flex justify-center py-2">
          <div className="relative w-64 h-64 sm:w-72 sm:h-72 rounded-full bg-[#181614] border-4 border-[#332f27] shadow-[0_12px_28px_rgba(0,0,0,0.85),inset_0_4px_12px_rgba(0,0,0,0.9)] flex items-center justify-center transform-gpu [transform:rotateX(12deg)_rotateY(-6deg)] transition-transform duration-700 hover:[transform:rotateX(0deg)_rotateY(0deg)]">
            
            {/* Convex Glass Lens Glare Sheen */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-transparent via-white/5 to-white/20 pointer-events-none z-30" />

            {/* Inner Dial Face: Aged Vintage Ivory Canvas */}
            <div className="relative w-56 h-56 sm:w-64 sm:h-64 rounded-full bg-[#e8e1d3] shadow-[inset_0_4px_16px_rgba(0,0,0,0.7)] flex flex-col items-center justify-center overflow-hidden border border-[#52493b]">
              
              {/* ASCII Dial Arch Background */}
              <pre className="absolute inset-0 flex items-center justify-center text-[7px] sm:text-[8px] leading-[1.05] text-[#4a443a] opacity-40 font-mono pointer-events-none">
{`       .----''''''----.
     .'  _  500 PSI _  '.
    /   / \\    |   / \\   \\
   / 250   \\   |  /   750 \\
  |         \\  | /         |
  | 0  ------\\(o)/------1000|
  |         /  | \\   [DANGER]
   \\       /   |  \\       /
    \\     /    |   \\     /
     '.  '----...----'  .'
       '--------------'`}
              </pre>

              {/* Red Critical Danger Sector Arc */}
              <div
                className="absolute top-3 right-6 text-[8px] font-bold text-[#b52a1d] tracking-tight uppercase flex items-center gap-1 z-10"
              >
                <ShieldAlert size={10} />
                <span>800+ CRITICAL</span>
              </div>

              {/* Unit Title & Dial Branding */}
              <div className="absolute top-12 flex flex-col items-center z-10">
                <span className="text-[10px] font-bold text-[#3d3830] tracking-widest uppercase">
                  {label}
                </span>
                <span className="text-[8px] text-[#696154] tracking-widest uppercase">
                  ATMOSPHERIC BLEED
                </span>
              </div>

              {/* Smoothly Interpolating ASCII Needle System */}
              {/* CSS transition ensures that angle changes smoothly without visual jumps */}
              <div
                className="absolute inset-0 flex items-center justify-center pointer-events-none z-20"
                style={{
                  transform: `rotate(${needleAngle}deg)`,
                  transformOrigin: '50% 50%',
                  transition: 'transform 650ms cubic-bezier(0.34, 1.4, 0.64, 1)',
                }}
              >
                {/* Pointer arm extending upward from center */}
                <div className="absolute bottom-1/2 flex flex-col items-center pb-2">
                  <span
                    className={`font-mono text-sm leading-none font-black ${
                      isCritical ? 'text-[#c72618]' : 'text-[#1c1a17]'
                    } drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)]`}
                  >
                    ▲
                  </span>

                  <div className="flex flex-col items-center -space-y-1.5 my-0.5">
                    <span className="text-xs font-bold text-[#1c1a17]">│</span>
                    <span className="text-xs font-bold text-[#1c1a17]">│</span>
                    <span className="text-xs font-bold text-[#1c1a17]">│</span>
                    <span className="text-xs font-bold text-[#1c1a17]">│</span>
                    <span className="text-xs font-bold text-[#1c1a17]">│</span>
                    <span className="text-xs font-bold text-[#1c1a17]">│</span>
                  </div>
                </div>

                {/* Center Pivot Bushing */}
                <div className="w-5 h-5 rounded-full bg-[#b89558] border-2 border-[#544122] flex items-center justify-center shadow-md z-30">
                  <div className="w-2 h-2 rounded-full bg-[#1c1a17]" />
                </div>

                {/* Counterweight Tail extending downward from center */}
                <div className="absolute top-1/2 flex flex-col items-center pt-2 -space-y-1">
                  <span className="text-[10px] text-[#3d3830]">│</span>
                  <span className="text-xs font-bold text-[#3d3830]">▼</span>
                </div>
              </div>

              {/* Real-time Numeric Readout on Dial Base */}
              <div className="absolute bottom-10 flex flex-col items-center z-10 bg-[#dfd7c7]/90 px-3 py-1 rounded-xs border border-[#4d4538] shadow-xs">
                <span className="text-[8px] text-[#696154] tracking-widest uppercase">
                  TELEMETRY
                </span>
                <span className="font-display font-black text-sm tabular-nums tracking-wider text-[#1a1816]">
                  {Math.round(clampedPressure)} <span className="text-xs font-bold text-[#696154]">{unit}</span>
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Controls: Test Smooth Interpolation Without Instant Jumps */}
        <div className="mt-3 pt-3 border-t border-[#26231d] space-y-2">
          <div className="flex items-center justify-between text-[10px] text-[#8a8479]">
            <span className="uppercase tracking-wider">SMOOTH NEEDLE INTERPOLATION TEST:</span>
            <button
              type="button"
              onClick={() => setAutoCycle(!autoCycle)}
              className={`px-2 py-0.5 border text-[9px] font-bold uppercase transition-colors cursor-pointer flex items-center gap-1 ${
                autoCycle
                  ? 'bg-[#d96528] text-white border-[#d96528]'
                  : 'bg-[#1b1a18] text-[#8a8479] border-[#38332a] hover:text-[#f2ede4]'
              }`}
            >
              <Activity size={10} className={autoCycle ? 'animate-pulse' : ''} />
              <span>{autoCycle ? 'AUTO-CYCLING' : 'AUTO CYCLE'}</span>
            </button>
          </div>

          {/* Quick Target Pressure Buttons */}
          <div className="grid grid-cols-4 gap-1.5 text-xs">
            <button
              type="button"
              onClick={() => handleSetPressure(80)}
              className={`py-1.5 px-1 border text-[10px] font-bold uppercase transition-all cursor-pointer ${
                pressure === 80
                  ? 'bg-[#2b2721] text-[#d96528] border-[#d96528]'
                  : 'bg-[#181715] text-[#9c9486] border-[#332f28] hover:border-[#524b3f] hover:text-[#f2ede4]'
              }`}
            >
              80 PSI
            </button>

            <button
              type="button"
              onClick={() => handleSetPressure(340)}
              className={`py-1.5 px-1 border text-[10px] font-bold uppercase transition-all cursor-pointer ${
                pressure === 340
                  ? 'bg-[#2b2721] text-[#d96528] border-[#d96528]'
                  : 'bg-[#181715] text-[#9c9486] border-[#332f28] hover:border-[#524b3f] hover:text-[#f2ede4]'
              }`}
            >
              340 PSI
            </button>

            <button
              type="button"
              onClick={() => handleSetPressure(650)}
              className={`py-1.5 px-1 border text-[10px] font-bold uppercase transition-all cursor-pointer ${
                pressure === 650
                  ? 'bg-[#2b2721] text-[#d96528] border-[#d96528]'
                  : 'bg-[#181715] text-[#9c9486] border-[#332f28] hover:border-[#524b3f] hover:text-[#f2ede4]'
              }`}
            >
              650 PSI
            </button>

            <button
              type="button"
              onClick={() => handleSetPressure(920)}
              className={`py-1.5 px-1 border text-[10px] font-bold uppercase transition-all cursor-pointer ${
                pressure === 920
                  ? 'bg-[#3b1c19] text-[#e04536] border-[#c72618]'
                  : 'bg-[#181715] text-[#b86156] border-[#4a2622] hover:border-[#82332c] hover:text-[#e04536]'
              }`}
            >
              920 PSI!
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
