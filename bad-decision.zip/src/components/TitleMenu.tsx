import React, { useState } from 'react';
import { LevelDefinition } from '../types/game';
import { sound } from '../audio/sound';
import { Gauge3D } from './Gauge3D';

interface TitleMenuProps {
  levels: LevelDefinition[];
  unlockedLevels: number;
  bestMoves: Record<string, number>;
  incidentCount: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onStartLevel: (lvlNum: number) => void;
  onOpenArchive: () => void;
}

export const TitleMenu: React.FC<TitleMenuProps> = ({
  levels,
  unlockedLevels,
  bestMoves,
  incidentCount,
  onStartLevel,
  onOpenArchive,
}) => {
  const [sectorRange, setSectorRange] = useState<'ALL' | '1-10' | '11-20' | '21-30' | '31-40' | '41-50'>('1-10');

  const filteredLevels = levels.filter((lvl) => {
    if (sectorRange === 'ALL') return true;
    if (sectorRange === '1-10') return lvl.levelNumber >= 1 && lvl.levelNumber <= 10;
    if (sectorRange === '11-20') return lvl.levelNumber >= 11 && lvl.levelNumber <= 20;
    if (sectorRange === '21-30') return lvl.levelNumber >= 21 && lvl.levelNumber <= 30;
    if (sectorRange === '31-40') return lvl.levelNumber >= 31 && lvl.levelNumber <= 40;
    if (sectorRange === '41-50') return lvl.levelNumber >= 41 && lvl.levelNumber <= 50;
    return true;
  });

  return (
    <div
      className="w-full font-mono transition-colors duration-150"
      style={{ color: 'var(--text-pri)' }}
    >
      {/* Editorial Game Entrance with Interactive 3D ASCII Gauge */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-10">
        <div className="lg:col-span-7">
          <div
            className="text-[11px] uppercase tracking-widest mb-3"
            style={{ color: 'var(--text-mut)' }}
          >
            EXPERIMENTAL ANALOG RIG · 1974 · 50 CHAMBERS
          </div>
          <h1
            className="text-4xl sm:text-6xl font-display font-bold tracking-tight leading-none mb-4"
            style={{ color: 'var(--text-pri)' }}
          >
            BAD DECISION.
          </h1>
          <div className="space-y-1 text-base sm:text-lg text-[#d96528] font-display font-semibold mb-6">
            <p>Fifty chambers.</p>
            <p>One wrong flip is fatal.</p>
          </div>
          <p
            className="text-xs sm:text-sm leading-relaxed mb-2 max-w-xl"
            style={{ color: 'var(--text-sec)' }}
          >
            You stand before an analog experimental control system. Every switch, valve, and lever has a physical, deterministic consequence.
          </p>
          <p
            className="text-xs sm:text-sm leading-relaxed mb-8 max-w-xl"
            style={{ color: 'var(--text-mut)' }}
          >
            Observe the gauges before you act. Physics is deterministic; ignorance is loud.
          </p>

          {/* Direct action buttons */}
          <div className="flex flex-wrap items-center gap-4 text-xs">
            <button
              type="button"
              onClick={() => {
                sound.playSwitchClick();
                onStartLevel(1);
              }}
              className="px-6 py-3 bg-[#d96528] hover:bg-[#ea7535] text-white font-bold tracking-wider uppercase transition-colors cursor-pointer shadow-sm rounded-xs"
            >
              [ COMMENCE TEST ]
            </button>

            <button
              type="button"
              onClick={onOpenArchive}
              className="px-5 py-3 border font-bold tracking-wider uppercase transition-colors cursor-pointer rounded-xs hover:border-[#d96528]"
              style={{
                backgroundColor: 'var(--bg-card)',
                borderColor: 'var(--border-main)',
                color: 'var(--text-pri)',
              }}
            >
              [ INCIDENT ARCHIVE {incidentCount > 0 ? `(${incidentCount})` : ''} ]
            </button>
          </div>
        </div>

        {/* 3D Gauge Viewport with Smoothly Interpolating ASCII Needle */}
        <div className="lg:col-span-5 flex justify-center">
          <Gauge3D initialPressure={480} min={0} max={1000} label="LINE PRESSURE" unit="PSI" />
        </div>
      </div>

      <div
        className="w-full h-px my-8"
        style={{ backgroundColor: 'var(--border-subtle)' }}
      />

      {/* Experimental Chamber Roster (Clean Technical Ledger with Sector Tabs) */}
      <div>
        <div
          className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs uppercase tracking-wider mb-4 pb-1 border-b"
          style={{
            borderColor: 'var(--border-subtle)',
            color: 'var(--text-mut)',
          }}
        >
          <span>TEST CHAMBER ROSTER</span>
          <span>PROGRESSION: {Math.min(unlockedLevels, levels.length)} / {levels.length} ACCESSIBLE</span>
        </div>

        {/* Sector Grouping Tabs for 50 Levels */}
        <div className="flex flex-wrap gap-1.5 mb-6 text-[10px]">
          {(['1-10', '11-20', '21-30', '31-40', '41-50', 'ALL'] as const).map((rng) => (
            <button
              key={rng}
              type="button"
              onClick={() => {
                sound.playSwitchClick();
                setSectorRange(rng);
              }}
              className={`px-3 py-1 font-bold uppercase transition-colors border cursor-pointer rounded-xs ${
                sectorRange === rng ? 'bg-[#d96528] text-white border-[#d96528]' : ''
              }`}
              style={{
                backgroundColor: sectorRange === rng ? '#d96528' : 'var(--bg-card)',
                color: sectorRange === rng ? '#ffffff' : 'var(--text-mut)',
                borderColor: sectorRange === rng ? '#d96528' : 'var(--border-main)',
              }}
            >
              {rng === 'ALL' ? 'ALL 50 CHAMBERS' : `CHAMBERS ${rng}`}
            </button>
          ))}
        </div>

        <div
          className="divide-y"
          style={{ borderColor: 'var(--border-subtle)' }}
        >
          {filteredLevels.map((lvl) => {
            const isUnlocked = lvl.levelNumber <= unlockedLevels;
            const bestScore = bestMoves[lvl.id];
            const isBeaten = bestScore !== undefined;

            return (
              <div
                key={lvl.id}
                className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                style={{ borderColor: 'var(--border-subtle)' }}
              >
                <div className="flex items-start sm:items-center gap-4">
                  <span className="font-mono text-sm text-[#d96528] font-bold w-8 shrink-0">
                    {lvl.levelNumber < 10 ? `0${lvl.levelNumber}` : lvl.levelNumber}
                  </span>
                  <div>
                    <div className="flex items-center gap-3">
                      <span
                        className="font-display text-sm sm:text-base font-bold uppercase"
                        style={{ color: 'var(--text-pri)' }}
                      >
                        {lvl.title}
                      </span>
                      <span
                        className="text-[10px] uppercase"
                        style={{ color: 'var(--text-mut)' }}
                      >
                        {lvl.subtitle}
                      </span>
                    </div>
                    <p
                      className="text-[11px] mt-0.5 leading-relaxed"
                      style={{ color: 'var(--text-sec)' }}
                    >
                      {lvl.objective}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-6 self-end sm:self-center shrink-0">
                  <div
                    className="text-[11px]"
                    style={{ color: 'var(--text-mut)' }}
                  >
                    {isBeaten ? (
                      <span className="text-[#3ba54b] font-bold">
                        CLEARED ({bestScore} MOVES · PAR {lvl.parMoves < 10 ? `0${lvl.parMoves}` : lvl.parMoves})
                      </span>
                    ) : (
                      <span>PAR {lvl.parMoves < 10 ? `0${lvl.parMoves}` : lvl.parMoves}</span>
                    )}
                  </div>

                  {isUnlocked ? (
                    <button
                      type="button"
                      onClick={() => {
                        sound.playSwitchClick();
                        onStartLevel(lvl.levelNumber);
                      }}
                      className="px-3 py-1.5 border font-bold uppercase tracking-wider transition-colors cursor-pointer rounded-xs hover:bg-[#d96528] hover:text-white hover:border-[#d96528]"
                      style={{
                        backgroundColor: 'var(--bg-card)',
                        borderColor: 'var(--border-main)',
                        color: 'var(--text-pri)',
                      }}
                    >
                      ENGAGE →
                    </button>
                  ) : (
                    <span
                      className="uppercase font-bold tracking-wider px-3 py-1.5 opacity-50"
                      style={{ color: 'var(--text-dim)' }}
                    >
                      RESTRICTED
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Minimal Footer */}
      <div
        className="mt-12 pt-4 border-t flex flex-col sm:flex-row items-center justify-between text-[11px] gap-2"
        style={{
          borderColor: 'var(--border-subtle)',
          color: 'var(--text-dim)',
        }}
      >
        <span>1970S MECHANICAL LABORATORY SIMULATION · 50 TOTAL CHAMBERS</span>
        <span>KEYBOARD SHORTCUTS: [1-9] ACTUATORS · [R] RESET · [ESC] CONSOLE</span>
      </div>
    </div>
  );
};
