import React from 'react';
import { Volume2, VolumeX } from 'lucide-react';

interface TopBarProps {
  currentView: string;
  incidentCount: number;
  soundEnabled: boolean;
  onNavigate: (view: 'MENU' | 'PLAYING' | 'ARCHIVE') => void;
  onToggleSound: () => void;
  onStartLatest: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentView,
  incidentCount,
  soundEnabled,
  onNavigate,
  onToggleSound,
  onStartLatest,
}) => {
  return (
    <header
      className="w-full border-b font-mono text-xs transition-colors duration-150"
      style={{
        backgroundColor: 'var(--bg-app)',
        borderColor: 'var(--border-subtle)',
        color: 'var(--text-pri)',
      }}
    >
      <div className="w-full max-w-5xl mx-auto px-4 sm:px-6 pt-3 pb-2.5 flex items-center justify-between">
        {/* Zone 1: Single text wordmark */}
        <button
          type="button"
          onClick={() => onNavigate('MENU')}
          className="font-display font-bold text-base sm:text-lg tracking-tight hover:text-[#d96528] transition-colors uppercase cursor-pointer"
          style={{ color: 'var(--text-pri)' }}
        >
          BAD DECISION
        </button>

        {/* Zone 2: Clean single-line text navigation links */}
        <nav
          className="flex items-center gap-4 sm:gap-8 text-xs"
          style={{ color: 'var(--text-mut)' }}
        >
          <button
            type="button"
            onClick={() => onNavigate('MENU')}
            className={`hover:text-[#d96528] transition-colors cursor-pointer uppercase ${
              currentView === 'MENU' ? 'text-[#d96528] font-bold' : ''
            }`}
          >
            CONSOLE
          </button>

          <button
            type="button"
            onClick={() => onNavigate('PLAYING')}
            className={`hover:text-[#d96528] transition-colors cursor-pointer uppercase ${
              currentView === 'PLAYING' ? 'text-[#d96528] font-bold' : ''
            }`}
          >
            APPARATUS
          </button>

          <button
            type="button"
            onClick={() => onNavigate('ARCHIVE')}
            className={`hover:text-[#d96528] transition-colors cursor-pointer uppercase ${
              currentView === 'ARCHIVE' ? 'text-[#d96528] font-bold' : ''
            }`}
          >
            INCIDENTS ({incidentCount})
          </button>
        </nav>

        {/* Zone 3: Primary minimal actions */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onToggleSound}
            className="transition-colors cursor-pointer p-1 hover:text-[#d96528]"
            style={{ color: 'var(--text-mut)' }}
            title={soundEnabled ? 'Audio: Active' : 'Audio: Muted'}
            aria-label={soundEnabled ? 'Mute audio' : 'Enable audio'}
          >
            {soundEnabled ? (
              <span className="flex items-center gap-1 text-[11px]">
                <Volume2 size={13} className="text-[#d96528]" />
                <span className="hidden sm:inline">SOUND</span>
              </span>
            ) : (
              <span className="flex items-center gap-1 text-[11px] opacity-60">
                <VolumeX size={13} />
                <span className="hidden sm:inline">MUTED</span>
              </span>
            )}
          </button>

          <span
            className="hidden sm:inline opacity-30"
            style={{ color: 'var(--text-mut)' }}
          >
            |
          </span>

          <button
            type="button"
            onClick={onStartLatest}
            className="text-[#d96528] hover:text-[#ea7535] font-bold text-xs uppercase cursor-pointer"
          >
            {currentView === 'PLAYING' ? '[R] RESET' : 'COMMENCE →'}
          </button>
        </div>
      </div>
    </header>
  );
};
