"""
Embeddings are behind a small interface so a new provider is a new class,
not a rewrite of the pipeline or retrieval code. Only "openai" ships today;
adding a local/HuggingFace provider later means implementing `EmbeddingService`
and registering it in `get_embedding_service()` — nothing else changes.
"""

from abc import ABC, abstractmethod

from app.core.config import settings


class EmbeddingService(ABC):
    @abstractmethod
    def embed_documents(self, texts: list[str]) -> list[list[float]]: ...

    @abstractmethod
    def embed_query(self, text: str) -> list[float]: ...


class OpenAIEmbeddingService(EmbeddingService):
    def __init__(self, model: str, api_key: str):
        from langchain_openai import OpenAIEmbeddings

        self._client = OpenAIEmbeddings(model=model, api_key=api_key)

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return self._client.embed_documents(texts)

    def embed_query(self, text: str) -> list[float]:
        return self._client.embed_query(text)


_instance: EmbeddingService | None = None


def get_embedding_service() -> EmbeddingService:
    global _instance
    if _instance is not None:
        return _instance

    provider = settings.embedding_provider.lower()
    if provider == "openai":
        if not settings.openai_api_key:
            raise RuntimeError(
                "EMBEDDING_PROVIDER=openai requires OPENAI_API_KEY to be set in backend/.env"
            )
        _instance = OpenAIEmbeddingService(settings.embedding_model, settings.openai_api_key)
    else:
        raise RuntimeError(
            f"Unsupported EMBEDDING_PROVIDER '{provider}'. Add a new EmbeddingService "
            "subclass in app/rag/embeddings.py and register it here."
        )
    return _instance
