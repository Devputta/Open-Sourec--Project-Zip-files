import { HardDrive } from "lucide-react";
import { Card, CardContent } from "@/components/ui/Card";
import type { StorageSummary } from "@/types/document";

function formatBytes(bytes: number) {
  if (bytes === 0) return "0 MB";
  const mb = bytes / (1024 * 1024);
  return mb < 1024 ? `${mb.toFixed(1)} MB` : `${(mb / 1024).toFixed(1)} GB`;
}

export function StorageCard({ summary }: { summary: StorageSummary }) {
  const pct = Math.min(
    100,
    Math.round((summary.usedBytes / summary.limitBytes) * 100)
  );

  return (
    <Card>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <HardDrive className="h-4 w-4 text-text-muted" strokeWidth={1.75} />
          <span className="text-sm font-medium text-text-primary">Storage</span>
        </div>

        <div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-surface-2">
            <div
              className="h-full rounded-full bg-brand"
              style={{ width: `${pct}%` }}
            />
          </div>
          <p className="mt-2 text-xs text-text-secondary">
            {formatBytes(summary.usedBytes)} of {formatBytes(summary.limitBytes)} used
          </p>
        </div>

        <div className="flex items-center justify-between border-t border-border pt-3 text-xs text-text-secondary">
          <span>Documents</span>
          <span className="font-mono text-text-primary">
            {summary.documentCount} / {summary.documentLimit}
          </span>
        </div>
      </CardContent>
    </Card>
  );
}
