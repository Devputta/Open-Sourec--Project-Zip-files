import { DashboardShell } from "@/components/dashboard/DashboardShell";
import { WelcomeCard } from "@/components/dashboard/WelcomeCard";
import { RecentDocuments } from "@/components/dashboard/RecentDocuments";
import { RecentConversations } from "@/components/dashboard/RecentConversations";
import { StorageCard } from "@/components/dashboard/StorageCard";
import {
  mockDocuments,
  mockConversations,
  mockStorageSummary,
} from "@/lib/mock-data";

export default function DashboardPage() {
  return (
    <DashboardShell>
      <div className="mx-auto max-w-5xl space-y-6">
        <WelcomeCard />

        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            <RecentDocuments documents={mockDocuments} />
            <RecentConversations conversations={mockConversations} />
          </div>
          <div>
            <StorageCard summary={mockStorageSummary} />
          </div>
        </div>
      </div>
    </DashboardShell>
  );
}
